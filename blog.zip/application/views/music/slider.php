<!-- slider_area_start -->
<div class="slider_area">
    <div class="single_slider  d-flex align-items-center slider_bg_1 overlay2">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="slider_text text-center ">
                        <h3><?php echo $mname ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- slider_area_end -->