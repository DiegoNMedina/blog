<div class="bradcam_area breadcam_bg_2">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="bradcam_text text-center">
                    <h3> <?php echo $title ?></h3>
                </div>
            </div>
        </div>  
    </div>
</div>