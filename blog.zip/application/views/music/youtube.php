 <!-- youtube_video_area  -->
 <div class="youtube_video_area">
     <div class="container-fluid p-0">
         <div class="row no-gutters">
             <div class="col-xl-3 col-lg-3 col-md-6">
                 <div class="single_video">
                     <div class="thumb">
                         <img src="<?= base_url(); ?>assets/music/img/video/apache.jpg" alt="">
                     </div>
                     <div class="hover_elements">
                         <div class="video">
                             <a class="popup-video" href="https://www.youtube.com/watch?v=hSTAR7bFcqA">
                                 <i class="fa fa-play"></i>
                             </a>
                         </div>

                         <div class="hover_inner">
                             <span>Son Destello - 2018</span>
                             <h3><a href="#">Cumbia Apache</a></h3>
                         </div>
                     </div>
                 </div>
             </div>
             <div class="col-xl-3 col-lg-3 col-md-6">
                 <div class="single_video">
                     <div class="thumb">
                         <img src="<?= base_url(); ?>assets/music/img/video/china.jpg" alt="">
                     </div>
                     <div class="hover_elements">
                         <div class="video">
                             <a class="popup-video" href="https://www.youtube.com/watch?v=IZaP8EIpbuA">
                                 <i class="fa fa-play"></i>
                             </a>
                         </div>

                         <div class="hover_inner">
                             <span>Son Destello - 2018</span>
                             <h3><a href="#">Cumbia en la china</a></h3>
                         </div>
                     </div>
                 </div>
             </div>
             <div class="col-xl-3 col-lg-3 col-md-6">
                 <div class="single_video">
                     <div class="thumb">
                         <img src="<?= base_url(); ?>assets/music/img/video/llanero.jpg" alt="">
                     </div>
                     <div class="hover_elements">
                         <div class="video">
                             <a class="popup-video" href="https://www.youtube.com/watch?v=cAJxaxYgf20">
                                 <i class="fa fa-play"></i>
                             </a>
                         </div>

                         <div class="hover_inner">
                             <span>Son Destello - 2018</span>
                             <h3><a href="#">El llanero solitario</a></h3>
                         </div>
                     </div>
                 </div>
             </div>
             <div class="col-xl-3 col-lg-3 col-md-6">
                 <div class="single_video">
                     <div class="thumb">
                         <img src="<?= base_url(); ?>assets/music/img/video/playas.jpg" alt="">
                     </div>
                     <div class="hover_elements">
                         <div class="video">
                             <a class="popup-video" href="https://www.youtube.com/watch?v=FqnbtP9X67U">
                                 <i class="fa fa-play"></i>
                             </a>
                         </div>

                         <div class="hover_inner">
                             <span>Son Destello - 2019</span>
                             <h3><a href="#">Las playas de Amalucan</a></h3>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
 <!-- / youtube_video_area  -->