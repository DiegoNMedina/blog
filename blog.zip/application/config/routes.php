<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'blog';
$route['404_override'] = 'notfound/index';
$route['translate_uri_dashes'] = FALSE;
